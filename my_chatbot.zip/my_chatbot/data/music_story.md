## Generated Story 5697831356519376206
* greet
    - utter_greet
* inform_style{"style": "\u6b22\u5feb"}
    - slot{"style": "\u6b22\u5feb"}
    - action_search_listen
* inform_name{"name": "\u544a\u767d\u6c14\u7403"}
    - slot{"name": "\u544a\u767d\u6c14\u7403"}
    - action_search_listen
    - action_search_listen
* inform_singer{"singer": "\u5468\u6770\u4f26"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_consume
    - export

## Generated Story -4229886833255162083
* greet
    - utter_greet
* inform_name{"name": "\u6012\u653e\u7684\u751f\u547d"}
    - slot{"name": "\u6012\u653e\u7684\u751f\u547d"}
    - action_search_listen
* inform_singer{"singer": "\u6c6a\u5cf0"}
    - slot{"singer": "\u6c6a\u5cf0"}
    - action_search_listen
* request_search
    - action_search_consume
    - export

## Generated Story 1434729922732292628
* confirm
    - action_search_listen
* request_search{"name": "\u8bb8\u5c11\u5e74"}
    - slot{"name": "\u8bb8\u5c11\u5e74"}
    - action_search_listen
* satisfy
    - action_search_consume
    - export

## Generated Story -9090016755693332464
* greet
    - utter_greet
* inform_singer{"singer": "\u5468\u6770\u4f26"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_listen
    - action_search_listen
* inform_name{"name": "\u7a3b\u9999"}
    - slot{"name": "\u7a3b\u9999"}
    - action_search_consume
* thanks
    - utter_thanks
    - export

## Generated Story 4304011294228060896
* greet
    - utter_greet
* request_search{"name": "\u544a\u767d\u6c14\u7403"}
    - slot{"name": "\u544a\u767d\u6c14\u7403"}
    - action_search_listen
* inform_singer{"singer": "\u5468\u6770\u4f26"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_consume
* thanks
    - utter_thanks
    - export

## Generated Story -842960985046495265
* greet
    - utter_greet
* request_search{"style": "\u6447\u6eda"}
    - slot{"style": "\u6447\u6eda"}
    - action_search_listen
    - utter_ask_singer
* inform_singer{"singer": "\u4e94\u6708\u5929"}
    - slot{"singer": "\u4e94\u6708\u5929"}
    - action_search_consume
* thanks
    - utter_thanks
    - export

## Generated Story -6678057259814637136
* greet
    - utter_greet
* request_search{"singer": "\u5468\u6770\u4f26", "name": "\u544a\u767d\u6c14\u7403"}
    - slot{"name": "\u544a\u767d\u6c14\u7403"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_consume
* goodbye
    - utter_goodbye
    - export

## Generated Story -8046472177413219362
* greet
    - utter_greet
* request_search{"singer": "\u4e94\u6708\u5929"}
    - slot{"singer": "\u4e94\u6708\u5929"}
    - action_search_listen
* inform_style{"name": "\u62e5\u62b1"}
    - slot{"name": "\u62e5\u62b1"}
    - action_search_consume
* thanks
    - utter_thanks
    - export

## Generated Story -5968042992673466446
* greet
    - utter_greet
* inform_singer{"singer": "\u9093\u7d2b\u68cb"}
    - slot{"singer": "\u9093\u7d2b\u68cb"}
    - utter_ask_style
    - action_search_listen
* inform_style{"style": "\u60c5\u6b4c"}
    - slot{"style": "\u60c5\u6b4c"}
    - action_search_consume
* thanks
    - utter_thanks
    - export

## Generated Story -3354526719240587299
* request_search{"singer": "\u5468\u6770\u4f26", "name": "\u544a\u767d\u6c14\u7403"}
    - slot{"name": "\u544a\u767d\u6c14\u7403"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_consume
    - export

## Generated Story 6277822535690319492
* greet
    - utter_greet
* request_search{"singer": "\u5468\u6770\u4f26"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_listen
* request_search{"name": "\u7a3b\u9999"}
    - slot{"name": "\u7a3b\u9999"}
    - action_search_consume
* thanks{"style": "\u54e6"}
    - slot{"style": "\u54e6"}
    - utter_thanks
    - export

## Generated Story -1289765401618491714
* greet
    - utter_greet
* request_search{"name": "\u62e5\u62b1"}
    - slot{"name": "\u62e5\u62b1"}
    - action_search_listen
* request_search{"singer": "\u4e94\u6708\u5929"}
    - slot{"singer": "\u4e94\u6708\u5929"}
    - action_search_consume
* thanks
    - utter_thanks
    - export

## Generated Story -1128736031965430367
* greet
    - utter_greet
* request_search{"singer": "\u5468\u6770\u4f26"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_listen
* request_search{"name": "\u7a3b\u9999"}
    - slot{"name": "\u7a3b\u9999"}
    - action_search_consume
* thanks
    - utter_thanks
    - export

## Generated Story -7408412687456588328
* greet
    - utter_greet
* request_search{"name": "\u544a\u767d\u6c14\u7403"}
    - slot{"name": "\u544a\u767d\u6c14\u7403"}
    - action_search_listen
* satisfy
    - action_search_consume
* thanks
    - utter_thanks
    - export


## Generated Story -821703034690203104
* greet
    - utter_greet
* request_search{"name": "\u4e94\u5c81"}
    - slot{"name": "\u4e94\u5c81"}
    - action_search_listen
* satisfy
    - action_search_consume
    - export

## Generated Story -8465461119369771274
* greet
    - utter_greet
* request_search{"name": "\u7406\u60f3"}
    - slot{"name": "\u7406\u60f3"}
    - action_search_listen
* inform_singer{"singer": "\u8d75\u96f7"}
    - slot{"singer": "\u8d75\u96f7"}
    - action_search_listen
* satisfy
    - action_search_consume
    - export

## Generated Story -2098810814073405523
* greet
    - utter_greet
* request_search{"singer": "\u8d75\u96f7", "style": "\u7406\u60f3"}
    - slot{"singer": "\u8d75\u96f7"}
    - slot{"style": "\u7406\u60f3"}
    - action_search_listen
    - action_search_consume
    - export

## Generated Story 1149254615102459893
* greet
    - utter_greet
* request_search{"singer": "\u8d75\u96f7"}
    - slot{"singer": "\u8d75\u96f7"}
    - action_search_listen
* satisfy
    - action_search_consume
    - export

