import csv
import codecs
with open('playlist_style1.csv','rt') as csvfile:
    reader = csv.DictReader(csvfile)
    column = [row['name'] for row in reader]
column = list(set(column))
fl=open('name_data.txt', 'w')
for i in column:
    fl.write(i)
    fl.write("\n")
fl.close()
