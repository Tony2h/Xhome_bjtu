import pymysql
db = pymysql.connect("localhost","root","123456","songDB")
cursor = db.cursor()
item = 'abc'
sql = "select * from song where name = \'{}\' ".format(item)
cursor.execute(sql)
results = cursor.fetchall()
if results == ():
    print("yes")


