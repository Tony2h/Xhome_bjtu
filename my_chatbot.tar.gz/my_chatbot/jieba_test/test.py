import jieba
jieba.load_userdict("test.txt")
seg_list = jieba.cut("给我来一首邓紫琪的夜空中最亮的星",cut_all = False)
print(",".join(seg_list))
