## Generated Story 1
* greet
    - utter_greet
* request_search{"singer": "周杰伦"}
    - slot{"singer": "周杰伦"}
    - action_search_listen
    - action_search_consume
* deny
    - utter_goodbye
    - export




## Generated Story 5697831356519376206
* greet
    - utter_greet
* inform_style{"style": "\u6b22\u5feb"}
    - slot{"style": "\u6b22\u5feb"}
    - action_search_listen
* inform_name{"name": "\u544a\u767d\u6c14\u7403"}
    - slot{"name": "\u544a\u767d\u6c14\u7403"}
    - action_search_listen
    - action_search_listen
* inform_singer{"singer": "\u5468\u6770\u4f26"}
    - slot{"singer": "\u5468\u6770\u4f26"}
    - action_search_consume
    - export

