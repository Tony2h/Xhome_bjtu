# Demo for 天气预报查询机器人

## 源代码地址
https://github.com/Tony2h/Xhome_bjtu

## 功能
这个机器人可以根据你提供的歌曲名（告白气球、怒放的生命等）,歌手名（周杰伦,汪峰等）和歌曲风格(欢快,悲伤)等查询出相应的歌曲名,歌手名,歌曲风格名。

## 特性
使用 Frame-based 对话管理方案，如果上述三个 Slot (歌曲名,歌手名,歌曲风格)，有任意一个用户未提供，对话管理系统会负责让你澄清相关 Slot 的值。

## 能力范围
* 受限于歌曲数据提供方的能力，这个机器人只能查询 **播放量比较多的歌曲** 。
* 暂时未实现点多首歌曲的功能.
* 受限于数据库，这个机器人 **只能查询提供的准确信息**，诸如**告白气球,汪峰**。

## 在线演示
见页面右下方的聊天widget ![chat_button](chat_button.png)，点击即可使用

## 作者

Xhome @ https://github.com/Tony2h/Xhome_bjtu

## Copyrights

<div>Robot icon in web-chat interface made by <a href="https://www.flaticon.com/authors/good-ware" title="Robotic">Robotic</a> from <a href="https://www.flaticon.com/"     title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"     title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
